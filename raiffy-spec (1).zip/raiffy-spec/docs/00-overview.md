# Raiffy: Overview

Raiffy is Raiffeisen Bank Romania's AI financial assistant. It helps individuals navigate financial decisions by comparing the ways to pay for a goal (how many depends on the question: see the answer scope rule in `docs/individuals/answer-patterns.md`), recommending one and saying why, showing every commission, and being honest about competitors while openly favoring Raiffeisen. The POC is English only, in the interface and in answers. Multi-language support comes later.

## Scope: individuals only

| Part | What it covers | Spec folder |
| --- | --- | --- |
| Individuals | Retail customers: rules, patterns, tools, evals, regulations | `docs/individuals/` |
| Core | Answer schema, pipeline, plan summaries, console, pricing, shared chats, customer experience | `docs/shared/` |

Business clients (PFAs, freelancers, liberal professions, micro and small companies) are **out of scope**. When a question is about financing a business, Raiffy says so and points to Raiffeisen's business channels (Smart Business, ERIC, an SME specialist). There is no track switch and no `track` parameter.

## Five layers (how every spec file is organized)

| Layer | Where it lives in the app |
| --- | --- |
| **Behavior rules** | System prompt, per-pattern prompts, fixed scripts, and the LLM evaluator's rubric |
| **Hard limits** | Code: guardrails, tool permissions, output checks, infrastructure; never prompt-only |
| **Calculations** | Deterministic, unit-tested tools and data rules; the LLM never does math |
| **Edge cases** | Evals and tests run on every change |
| **Regulations** | Compliance processes, documentation and official sources, owned by people |

Answer patterns (eleven structures), the answer schema (envelope plus blocks) and the six-step pipeline sit across these layers.

## File map

```
CLAUDE.md                                  instructions for Claude Code
docs/00-overview.md                        this file
docs/individuals/behavior-rules.md
docs/individuals/hard-limits.md
docs/individuals/calculations.md
docs/individuals/answer-patterns.md        core financing-route rule + 11 patterns
docs/individuals/evals.md
docs/individuals/regulations.md
docs/shared/answer-schema.md               envelope, 12 blocks, recipes, UI, i18n, build stack, demo
docs/shared/pipeline.md                    safety gate, router, orchestrator, evaluator, thinking panel
docs/shared/plan-summary-handoff.md        indicative plan PDF and handoff to official flows
docs/shared/console.md                     operator and admin console
docs/shared/pricing.md                     relationship pricing, competitor evidence, counter-offers
docs/shared/shared-chats.md                share links, members, one agent per prompt
docs/shared/customer-experience.md         CX decisions: self-declared income, no links, accessibility (overrides other files)
docs/shared/living-plan.md                 saved plan, loans and deposits buckets, Raiffeisen-only after first signing
docs/shared/smart-mobile-integration.md    entry points, context, deep links, reminders in Smart Mobile
docs/shared/money-saved.md                 the "money saved for customers" metric and its ledger
docs/decisions/product-decisions.md        stack, RAG, login and consent, landing page, human verification
docs/sources.md
```

## Source codes in tables

Many tables have a Source column. `EC` refers to the "Edge Cases, Concepts & Regulations" reference doc and `Auth` to the "Regulations by Authority" reference doc; neither is in this bundle, but the solutions taken from them are. Law names (e.g., OUG 50/2010) point to the regulation behind a rule.

## Build order

1. Core: schema and validators, safety gate, router, composer, calculator and comparison tools, evaluator checks, rendering registry, thinking panel.
2. Individuals answer patterns, starting with pattern 1 (purchase goal: the BMW X5 demo) and pattern 2 (product comparison).
3. Orchestrator and multi-goal plans; LLM evaluator rubric.
4. Plan summaries, human verification, landing page and login.

## Non-negotiables

- When money is involved, the number of routes follows the answer scope (compare: the options named; solution: every eligible borrowing route for the goal; detail: one product plus a follow-up question). Routes are ranked by total cost, including mandatory insurance such as CASCO, and the cheapest eligible, affordable route is recommended. Saving routes (deposits) appear only when the customer asks how to save up for something (pattern 5).
- Every commission listed, or "no commissions" stated only when every fee is confirmed zero and fresh.
- Every number comes from a tool, with a source and date; no number in text that isn't in a block.
- AI disclosure on the first message; a human always one tap away.
- Raiffeisen favored only openly; cheaper competitors always disclosed. Negotiation compares total cost first, then makes a counter-offer inside the pre-approved band or escalates to a specialist (pattern 11). Exception: after the customer's first solution signed through a Raiffy plan, competitors are compared only when the customer asks, and answers say they show Raiffeisen options (`docs/shared/living-plan.md`).
- Income and revenue are self-declared, never inferred from account data, and labelled as declared; the bank asks for proof when the customer applies (`docs/shared/customer-experience.md`).
- Raiffy never opens links; the customer types the price.
- No investment, tax or legal advice; refer out.
- Hardship and crisis modes suppress all offers.
- Values that change (rates, fees, tax thresholds, programmes) live in dated data or config, never in prompts.
