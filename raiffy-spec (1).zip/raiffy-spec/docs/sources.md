# Sources

Raiffeisen product pages are undated; they were read on 28 October 2026.

## Raiffeisen

- [Raiffeisen: Q2 2026 results](https://bvb.ro/infocont/infocont26/RBRO27A_20260730173229_RBRO-Financial-Results-2026-Q2-ENG.pdf)
- [Raiffeisen: Flexicredit T&C (2020)](https://banking.raiffeisen.ro/wps/wcm/connect/87fd1204-8f5e-41d9-a073-6c1f6a349317/20201212-Termeni-si-conditii-Flexicredit.pdf?MOD=AJPERES&CONVERT_TO=url&CACHEID=ROOTWORKSPACE-87fd1204-8f5e-41d9-a073-6c1f6a349317-oITnyvu&type=pdf)
- [Raiffeisen: Smart Mobile T&C, April 2026](https://www.raiffeisen.ro/content/dam/rbi/retail/eu/ro/documents/smart-mobile-termeni/20260417-Smart-Mobile-termeni-si-conditii.pdf.coredownload.inline.pdf)
- [Raiffeisen: Smart Mobile guide](https://www.raiffeisen.ro/content/dam/rbi/retail/eu/ro/documents/smart-mobile-ghid/20251010-smart-mobile-ghid.pdf.coredownload.pdf)

## Law and regulation

- [OUG 50/2010, art. 7 (consumer definition)](https://notari.pro/oug-50-2010-contractele-de-credit/art-7-obiect-domeniu-de-aplicare-si-definitii)
- [BNR Regulation 17/2012](https://www.avocatnet.ro/articol_31655/Regulamentul-BNR-nr-17-2012-unele-conditii-de-creditare.html)
- [BNR: 2026 draft amendment to Reg. 17/2012](https://www.bnr.ro/uploads/editor/1850860936.pdf)
- [Infocons: standard European consumer credit form](https://infocons.ro/care-este-forma-standard-la-nivel-european-privind-creditul-de-consum/)
