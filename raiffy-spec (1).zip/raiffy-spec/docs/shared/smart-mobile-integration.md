# Shared: Raiffy inside Smart Mobile

Raiffy lives where customers already manage their money. Two ideas carry the integration:

1. **"Ask Raiffy about this" on anything in Smart Mobile.** A product, a fee, a loan, a maturing deposit: one tap opens Raiffy already on that topic, so the customer never explains the context.
2. **The plan on the Smart Mobile home screen.** A plan card shows the loans and deposits buckets (`docs/shared/living-plan.md`) next to the accounts, so the plan is part of everyday banking, not a chat the customer has to remember.

In the POC, Smart Mobile is a mock frame in the HTML prototype.

## Entry points

Every entry point uses only product data the bank already holds (products, balances, rates, fees, maturity dates), under the customer's "What Raiffy can see" switches. **Never salary data or inferred income** (`docs/shared/customer-experience.md` §1).

| Where in Smart Mobile | What the customer taps or sees | Raiffy opens with | Pattern and scope |
| --- | --- | --- | --- |
| Home | The **plan card**: both buckets' progress, the next loan payment, savings on track or behind | The living plan | Plan view |
| Any product screen (loan, card, deposit, account package) | "Ask Raiffy about this" | The product, ready for questions | `detail` scope, ending with one follow-up question |
| A fee or commission line on a statement or transaction | "Why was I charged this?" | The fee and its date (not the counterparty) | Pattern 7, fees and statements |
| A loan screen | "Can I pay this off faster?" | The loan's balance, rate and remaining term | `solution` scope: early repayment vs keep paying, with the early-repayment fee |
| The loans and offers catalog | "Not sure which? Ask Raiffy" | The product category | `solution` scope, starting with the amount question |
| The app's search bar | A question typed in plain words | The question | Router as usual |
| A term deposit 7 days before maturity (reminder the customer turned on) | "Your 10,000 lei deposit matures on 4 Nov" | The deposit and any linked goal | Renew, put it toward the goal, or move to savings |
| A savings goal reached | "Your car goal is reached" | The goal and its deposits item | The next step for that goal, including keeping a buffer |
| A mortgage's fixed-rate period ending (reminder the customer turned on) | "Your fixed rate ends in 3 months" | The loan and its next rate basis | What changes and the options; Raiffeisen-only after the first signed solution, unless the customer asks (`docs/shared/living-plan.md`) |

## Context passed into Raiffy

Smart Mobile passes **IDs, never figures**. Raiffy reads the figures itself, under the customer's permissions, so a tampered link can't inject numbers.

```ts
type SmartMobileContext = {
  entry: "planCard" | "product" | "fee" | "loanPrepay" | "catalog" | "search" | "depositMaturity" | "goalReached" | "fixedRateEnd";
  productId?: string; feeId?: string; transactionId?: string; goalId?: string; planId?: string;
  query?: string;                    // search text, treated as the customer's first message
  issuedAt: string; expiresAt: string; // short-lived, for example 10 minutes
  signature: string;                 // signed by Smart Mobile; rejected if invalid or expired
};
```

- An invalid or expired context opens Raiffy normally, with no topic, and logs the attempt.
- The first answer says what it opened with: "You asked about the 15 lei fee on 21 Oct."

## Back into Smart Mobile

Every action that changes something happens in Smart Mobile, confirmed by the customer there (SmartToken or the app's usual confirmation). Raiffy only pre-fills.

| Raiffy action | Opens in Smart Mobile, pre-filled |
| --- | --- |
| "Apply in Smart Mobile" (loans bucket) | The loan application: product, amount, term (`docs/shared/plan-summary-handoff.md`) |
| "Open in Smart Mobile" (deposits bucket) | Opening a savings account or term deposit: product, amount, term |
| "Set up a standing order" (deposits bucket) | A standing order to the customer's own savings account: amount and day |
| "Send to my Inbox" | The plan summary PDF in the Smart Mobile Inbox |
| "Book an adviser" | The appointment booking, with the plan code attached (`docs/shared/customer-experience.md` §3) |

Each handoff has a `handoffId`, and Smart Mobile reports what happened (`OfficialFlowEvent` in `docs/shared/living-plan.md`), so the plan updates without the customer telling Raiffy.

## Identity

- Inside Smart Mobile, Raiffy uses the app's session: no second sign-in.
- Outside it (web), Raiffeisen SSO first, as in `docs/decisions/product-decisions.md`.

## Reminders

Reminders are service messages the customer turns on, never marketing.

| Rule | Layer |
| --- | --- |
| Off by default. The customer turns them on per plan ("Keep me posted about this plan") or per type (deposit maturity, fixed-rate end, savings behind) | Hard limits |
| Facts and options only: no product promotion in a reminder. A product appears only after the customer taps into Raiffy | Behavior rules |
| At most `reminders.maxPerWeek` per customer (dated parameter, default 2); urgent factual ones (a payment due) don't count toward it | Hard limits |
| Paused in hardship and crisis modes, except factual reminders about existing products | Hard limits |
| Delivered as a Smart Mobile notification and in the Inbox; every type can be switched off from the reminder itself | Behavior rules |

Marketing stays separate and needs the marketing consent (`docs/decisions/product-decisions.md` → Login, consent and marketing).

## HTML prototype (`smartmobile.html`)

A mock phone frame that opens `chat.html` with a context payload:

- A home screen with the plan card (both buckets).
- A loan screen with "Ask Raiffy about this" and "Can I pay this off faster?".
- A statement with a 15 lei fee and "Why was I charged this?".
- A deposit-maturity reminder that opens Raiffy on that deposit.
- Pre-filled handoff screens for a loan application, a term deposit and a standing order, each with a confirm button that sends a mock `OfficialFlowEvent`.

## Evals

| Check | Source |
| --- | --- |
| Each entry point opens the right pattern and scope, and the first answer names what it opened with | Entry points |
| The context carries IDs only; an invalid or expired signature opens Raiffy with no topic and is logged | Context passed into Raiffy |
| No entry point reads salary data or infers income | `docs/shared/customer-experience.md` §1 |
| Every Raiffy action pre-fills Smart Mobile; nothing is executed without the customer confirming there | Back into Smart Mobile |
| Reminders are off by default, carry no product promotion, respect the weekly limit and pause in hardship mode | Reminders |
| A handoff's official-flow event updates the living plan's status | Back into Smart Mobile |

## Open questions for Raiffeisen

- Webview inside Smart Mobile or native screens? Can Smart Mobile sign and pass a context payload?
- Which screens first? Suggested: the plan card, the fee line and the loans catalog.
- Can Smart Mobile send official-flow events (applied, signed, opened) back to Raiffy, and with what delay?
- Which notification channel and limits does the app already enforce?
