# Shared: Money saved for customers

Raiffy's trust metric is **the money customers saved by choosing a cheaper route with Raiffy**. It is computed by tools, counted conservatively, counted only when it has actually happened, and published with its method. It is a claim the bank must be able to prove line by line, so every part of it is a ledger entry with sources.

## Definition

> **Money saved** = the sum, over decisions that actually happened, of (reference total cost − chosen total cost), for the same goal, amount and horizon, computed by the calculator with the price versions shown at decision time.

- **Reference:** what the customer would have done without the cheaper choice, chosen by fixed rules (below), never by the LLM.
- **Chosen:** the route the customer actually signed, opened or completed.
- **Total cost:** interest plus every commission, mandatory insurance and required package, as in the DAE and total amount payable (`docs/individuals/calculations.md`).
- **Realized vs projected:** a saving is `projected` when the decision is made and becomes `realized` only as it actually happens (see "When it counts"). **Only realized savings are ever published.**

## What counts

| Kind | Reference | Chosen | Becomes realized |
| --- | --- | --- | --- |
| **Cheaper route** | The **cheaper** of: the route the customer named in their first message (for example "a car loan"), and the median total cost of the eligible borrowing routes shown. If they named none, the median | The loan signed | One-off fee differences at signing; interest differences month by month as each instalment is paid |
| **Refinancing** | The remaining cost of the existing loan at its current terms (from Raiffeisen data, a competitor statement or SECCI the customer confirmed, or declared figures, labelled as such) | The new loan's remaining cost | Fee differences at signing; interest month by month, only after the old loan is confirmed closed |
| **Fees avoided** | The fee the customer was paying, averaged over the 3 months before Raiffy explained it (`docs/individuals/answer-patterns.md` pattern 7) | No fee after the change (for example a different package or channel) | Each month the fee is absent from the bank's data, up to 12 months |
| **Counter-offer** | Raiffeisen's list total for the same loan | The counter-offer or specialist offer signed (`docs/shared/pricing.md`) | As for a cheaper route. Reported as its own line, because the reference is Raiffeisen's own price |

## What never counts

- Projections that haven't happened, savings on goals abandoned, and loans withdrawn within the withdrawal period (those entries are `reversed`).
- A reference the customer was never eligible for, or wasn't shown with a source and date.
- The gap to the most expensive route shown.
- Competitor references from typed claims, stale data or a SECCI the customer didn't confirm.
- Interest earned on deposits. It is real money, but it is shown separately as "interest earned", never added to money saved.
- The same decision twice: one entry per goal per decision, and a new decision for the same goal supersedes the old entry.

## The ledger

```ts
type SavingsEntry = {
  id: string;
  subjectId: string;                     // pseudonymized in every report
  planId: string; goalId: string;
  kind: "cheaperRoute" | "refinancing" | "feeAvoided" | "counterOffer";
  reference: { routeId: string; total: number; priceVersionIds: string[]; sourceIds: string[]; rule: string };
  chosen: { routeId: string; total: number; priceVersionIds: string[]; handoffId?: string };
  projectedAmount: number;               // reference.total − chosen.total at decision time
  realizedAmount: number;                // grows as events arrive
  currency: "RON" | "EUR";
  status: "projected" | "partlyRealized" | "realized" | "reversed";
  events: { kind: "signed" | "instalmentPaid" | "goalReached" | "feeAbsentMonth" | "oldLoanClosed" | "withdrawn" | "goalAbandoned"; at: string; amount: number }[];
  computedBy: string;                    // tool version
  createdAt: string; updatedAt: string;
};
```

- `savingsLedger.compute` is a pure, unit-tested tool. It reads the routes and price versions stored with the quote and never recomputes against today's prices.
- A Convex scheduled job applies official-flow and statement events (`docs/shared/living-plan.md`) to the open entries. In the POC the events are seeded.
- **The ledger never feeds the recommendation.** The router, orchestrator and composer can't read it, so the metric can't steer customers toward routes that "save more" on paper.

## Where it shows

| Audience | What they see |
| --- | --- |
| **The customer**, in the living plan | "You've saved 2,340 lei with Raiffy so far", with realized and projected shown separately. Each entry opens to show the reference and the chosen route, both totals, the sources, the dates and the rule used, worded "compared with [reference] for the same goal" |
| **The bank**, in the console | Realized and projected by kind, product and segment, over time; reversals; median per customer; the share of customers with any realized saving |
| **The public**, on the landing page | Realized money saved, rounded down (for example to the nearest 10,000 lei), the number of customers it covers, the median per customer, the period, and a link to a methodology page. Updated monthly, **only after compliance approves the figure** |

Wording rule: always "saved compared with [reference]". Never "saved thanks to our low prices", and never a saving without its reference.

## Keeping it honest

| Control | How |
| --- | --- |
| Fixed reference rules | The rules above live in code with eval cases; changing one is a code change, versioned and stored in `reference.rule` |
| Independent recomputation | Each month, a QA sample of at least 50 realized entries is recomputed from the stored price versions by someone outside the product team. Any mismatch blocks that month's public figure |
| Answers can't invent savings | The evaluator fails any answer that states a saving not in the ledger, or a saving without its reference |
| Methodology page | A public plain-language page with the definition, what counts, what never counts, and the rounding |
| Regulation | The public figure is a commercial claim, so it must be substantiated (Law 363/2007 on unfair commercial practices, comparative-advertising rules). Compliance signs off on the method once and on each published figure |

## Hackathon version

- Seed 10 to 20 ledger entries across the four kinds, with mock events, so the plan shows "You've saved…" with realized and projected amounts, and one entry opens to its reference.
- A landing-page figure from the seed data, labelled "Demo data".
- One slide: the definition, the realized-only rule, and the QA control.

## Evals

| Check | Source |
| --- | --- |
| The reference follows the fixed rule for each kind, and is always a route shown to the customer with a source and date | What counts |
| Nothing is realized before its event; a withdrawal or an abandoned goal reverses the entry | What counts · What never counts |
| Interest differences realize month by month, and fee differences at signing | What counts |
| Interest earned is never added to money saved | What never counts |
| One entry per goal per decision; a new decision supersedes the old one | What never counts |
| The recommendation is identical whether or not the ledger exists (the ledger isn't readable by the pipeline) | The ledger |
| No answer states a saving that isn't in the ledger, or without its reference | Keeping it honest |
| The public figure uses realized entries only, rounded down | Where it shows |

## Check with compliance

- The method, the wording and the rounding of the public figure.
- Whether counter-offer savings (measured against Raiffeisen's own list price) may appear in the public total or only internally.
