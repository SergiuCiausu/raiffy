# Shared: Customer experience

The target experience in one promise: **the customer never retypes anything, never waits without knowing why, never meets a surprise in the price or the conditions, and is never sold to when vulnerable.** This file records the customer-experience decisions agreed on 28 October 2026. Where it conflicts with another file, this file wins (see Precedence).

Scope: individuals only. Related files:

| Topic | File |
| --- | --- |
| The plan as a living object, the loans and deposits buckets, competitor comparisons after the first signed solution | `docs/shared/living-plan.md` |
| Raiffy inside Smart Mobile: entry points, context, deep links, reminders | `docs/shared/smart-mobile-integration.md` |
| The "money saved for customers" metric | `docs/shared/money-saved.md` |
| Deciding together in one chat | `docs/shared/shared-chats.md` (unchanged) |

## Precedence

| Topic | Overrides | Change |
| --- | --- | --- |
| Income | `docs/individuals/answer-patterns.md` (pattern 3 step 1, "from account data where available"), `docs/individuals/behavior-rules.md` ("Mention politely when stated data differs from account data"), `docs/shared/pricing.md` (`ClientProfile.monthlyIncome`) | Income is always **self-declared**. Raiffeisen doesn't hold salary data, and Raiffy never infers income from transactions (section 1) |
| Product prices from links | Anything implying Raiffy reads listings | Raiffy never opens links; the customer types the price (section 3) |
| Competitor comparisons | `docs/00-overview.md` non-negotiable "cheaper competitors always disclosed", `docs/individuals/answer-patterns.md` pattern 2 step 5, the matching evals | Unchanged **until the customer signs their first financial solution at Raiffeisen through a Raiffy plan**. After that, competitors are compared only when the customer asks (`docs/shared/living-plan.md`) |

## The promise, in build terms

| Promise | What makes it true |
| --- | --- |
| Never retype anything | Declared figures and goals are stored once in the profile and the plan, and reused. Handoffs to Smart Mobile are pre-filled. Smart Mobile opens Raiffy already on topic (`docs/shared/smart-mobile-integration.md`) |
| Never wait without knowing why | Thinking panel while tools run. Specialist reviews show a realistic wait time or a callback slot. Queued prompts in shared chats say "Waiting for your previous answer" |
| No surprise in price or conditions | Every commission listed; conditions on the card with the price both with and without them (`docs/shared/pricing.md`). Every figure labelled indicative until the bank issues the offer. The customer is told up front which documents the bank will ask for (section 1) |
| Never sold to when vulnerable | Hardship and crisis modes suppress all offers, counter-offers and proactive reminders that promote a product |

## 1. Income is self-declared

Raiffeisen doesn't store salary data, so Raiffy works with what the customer tells it and says so.

| Rule | Layer |
| --- | --- |
| Ask for the figure the first time a question needs it, in one short question: net monthly income. Accept round numbers and ranges | Behavior rules |
| Store it in the customer's profile and reuse it in every later answer and conversation. The customer can see and change it in the context panel at any time; a change applies to new answers and marks open plans "Figures updated" | Hard limits |
| **Never infer income** from transactions, incoming transfers or balances, and never compare the declared figure with account data | Hard limits |
| **Never ask for or accept proof** in Raiffy: no payslips, contracts, statements or tax returns. If the customer uploads one, don't read it, and explain that it goes to the bank when applying | Hard limits |
| Every answer that uses a declared figure says so next to the number: "Based on the income you told me: 6,500 lei a month". `affordability.incomeBasis` is `"self_declared"` | Behavior rules |
| Tell the customer early what the bank will ask for: "When you apply, the bank will ask for proof of your income, such as your employment contract or a salary certificate." The exact list comes from the product's `requiredDocuments` in the catalog, never from the LLM. Shown on the route card when the answer scope is `solution` or `compare`, on the plan summary, and before every handoff | Behavior rules · Calculations |
| If a declared figure falls outside a plausible range (a dated parameter, for example `income.plausibleMonthly`), ask once to confirm it, without judgment, then use what the customer confirms | Behavior rules |
| Existing obligations: Raiffeisen loans and cards come from the bank's product data under the "What Raiffy can see" switches; debts at other lenders are self-declared, in the same way as income | Hard limits |
| Shared chats: each person declares their own figures. A joint loan uses both declared incomes only after both agree in the chat (`docs/shared/shared-chats.md`) | Hard limits |

**Consequence for prices.** Prices stay indicative. Raiffy never turns a declared income into a firm or pre-approved price. Pre-approved offers that the bank's own systems already issued are still shown, as `docs/shared/pricing.md` describes. The firm offer always comes from the bank after the documents are checked.

```ts
type DeclaredFinancials = {
  subjectId: string;                 // the customer (Clerk user)
  netMonthlyIncome?: number;
  otherLenderObligations?: number;   // monthly payments at other lenders, declared
  incomeRange?: [number, number];    // when the customer gives a range
  currency: "RON" | "EUR";
  source: "self_declared";           // the only allowed value
  declaredAt: string;
  confirmedOutOfRange?: boolean;
};
```

## 2. Prices typed by the customer, never fetched

| Rule | Layer |
| --- | --- |
| **Raiffy never opens, fetches, previews or unfurls a URL**, from any source. The pipeline has no web-fetch tool on customer turns, and links in messages render as plain, non-clickable text | Hard limits |
| When a message contains a link or a pasted listing page, reply: "I can't open links. What's the price?" Also ask the one or two details that change eligibility or cost, taken from the domain pack (`priceQuestions`), for example the car's year (it decides whether leasing is possible) or whether a flat is new or old (VAT and notary costs) | Behavior rules |
| Screenshots or photos of listings get the same answer: Raiffy asks for the price and doesn't read the image. A competitor's SECCI or ESIS uploaded for negotiation is a different case and follows `docs/shared/pricing.md` | Hard limits |
| Prices are parsed by a deterministic tool ("about 25k euro", "25.000 €", "25,000 EUR"). The parsed amount and currency are confirmed back in the `inputs` block, editable. A conversion to lei uses the dated BNR rate with its source | Calculations |
| The typed price is stored with the goal in the plan and never asked again | Hard limits |

## 3. The same plan with a human or with Raiffy

| Rule | Layer |
| --- | --- |
| The specialist sees the same rendered blocks the customer sees (the console reuses the customer renderer registry), so both talk about identical figures | Hard limits |
| The specialist's reply lands in the chat thread as a signed message or a signed new version, never by email only | Behavior rules |
| Channels: an in-chat reply during working hours with a realistic wait time; a booked callback outside them. Video with screen sharing is a future improvement | Behavior rules |
| **Branch continuity:** each plan summary carries a short plan code (for example `RFY-7K3Q`, valid 30 days). At a branch, the customer gives the code and confirms in the chat; only then can the banker open that plan, read-only, in the console. The access is logged as a customer-triggered access (`docs/decisions/product-decisions.md` → Operator access) | Hard limits · Regulations |

## 4. Deciding together

Already specified in `docs/shared/shared-chats.md`: share by link, the author shown on every message, one agent per prompt running in parallel, at most 5 prompting accounts per chat. One addition:

- **Plan summaries from a shared chat** list the members who took part. They're sent only to the person who asked for them, as now.

## 5. Accessibility

Everyone can use Raiffy on their own terms. The baseline stays WCAG 2.1 AA (`CLAUDE.md`); the European Accessibility Act (Directive (EU) 2019/882) has applied to consumer banking services since 28 June 2025.

| Feature | What the customer gets | Build notes |
| --- | --- | --- |
| **Voice in, voice out** | Ask by voice; have the answer read aloud, including a spoken summary of each block ("Three ways to pay. The personal loan fits best: 1,240 lei a month, 3 commissions.") | Each block gets a `spokenSummary` built by the composer from tool data, never by the LLM. Read-aloud uses the formatted numbers |
| **Plain-language level** | A control with three levels, Simple, Standard and Detailed. Simple uses short sentences and explains terms like DAE inline | Changes only the framing `text` and the glossary hints. **Numbers, blocks and commissions are identical at every level**; the evaluator checks this |
| **Calm mode** | Larger type (18 px base and up), one route card at a time with next and previous, the whole answer shown at once instead of streaming, no motion, higher contrast, at most two follow-up suggestions, and a confirmation step before any handoff | Chosen by the customer in settings or on first use, never switched on automatically from age or any other personal trait |
| **Screen readers and keyboard** | Every block has a text alternative; charts also have a data table; full keyboard use | The gauge reads, for example: "Your payments would be 32% of your income, under the 40% limit." Streamed text reaches screen readers once through an ARIA live region |
| **Predictable layout** | The monthly cost, total cost and commissions badge are always in the same place on every card | Matches the render-variant rules in `docs/shared/answer-schema.md` |
| **Forgiving input** | Undo on sliders; nothing is lost on a timeout; spelling, missing diacritics and round numbers are accepted | A session timeout warns before it happens and keeps the draft |
| **Languages** | Deferred: the POC is English only (`CLAUDE.md` → POC overrides) | When added, follow `docs/shared/answer-schema.md` → Any language |

## Future improvements

- Video calls with screen sharing between the customer and a specialist.
- Multi-language support (already deferred).

## Evals

| Check | Source |
| --- | --- |
| No answer reads income or revenue from transactions or balances; every affordability block has `incomeBasis: "self_declared"` | Section 1 |
| Every answer that uses a declared figure labels it as declared, next to the number | Section 1 |
| The documents notice appears on the plan summary and before every handoff, and its list matches the catalog's `requiredDocuments` | Section 1 |
| An uploaded payslip or contract isn't read, and Raiffy explains that it goes to the bank when applying | Section 1 |
| A message with a link gets no fetch, and the answer asks for the price and the domain's eligibility questions | Section 2 |
| A listing screenshot isn't read; a competitor SECCI is still handled as `docs/shared/pricing.md` says | Section 2 |
| Price parsing handles "25k euro", "25.000 €" and "25,000 EUR", and a conversion shows the BNR rate with its date | Section 2 |
| A banker can open a plan only after the customer gives the plan code and confirms in the chat; the access is logged | Section 3 |
| The same question at the Simple and Detailed levels gives identical numbers and blocks | Section 5 |
| Calm mode renders every pattern's recipe without losing a block | Section 5 |
| Screen-reader and keyboard-only audit of every block, including `spokenSummary` and the data-table alternatives | Section 5 |

## Check with compliance

- The wording of the documents notice, and whether it must appear in the SECCI-like plan summary.
- Whether self-declared income is enough to show an indicative affordability gauge under BNR Regulation 17/2012 and the new Consumer Credit Directive, given that the bank verifies it later.
