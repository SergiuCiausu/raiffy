# Shared: Living plan

A plan isn't a chat message. It's a saved object that keeps the customer's goals, the routes they chose and their figures. It updates when prices or their figures change, and it splits into two buckets: **loans** and **deposits**. Once the customer has signed their first financial solution at Raiffeisen through Raiffy, the plan and every later answer show Raiffeisen options only, unless the customer asks to compare with other banks.

Extends `PlanSummary` in `docs/shared/plan-summary-handoff.md`; precedence is in `docs/shared/customer-experience.md`.

## Lifecycle

| State | Meaning | Set by |
| --- | --- | --- |
| `draft` | Routes chosen in the chat, not yet saved | Raiffy |
| `saved` | The customer tapped "Save my plan"; it appears in Raiffy and in Smart Mobile | Customer |
| `verified` | A specialist confirmed or edited it (`docs/decisions/product-decisions.md` → Human verification) | Specialist |
| `inProgress` | At least one item has been handed off to an official flow | Handoff event |
| `active` | At least one item is signed in the official flow | **Official-flow event only**, never Raiffy |
| `completed` | Every goal is reached, or every loan repaid | Official-flow and goal events |
| `archived` | Closed by the customer | Customer |

Raiffy never marks anything as applied, signed or opened by itself. Those states come only from events sent by the bank's official flows (mocked in the POC).

## Two buckets: loans and deposits

Every chosen route lands in exactly one bucket. The loans bucket fills from purchase, comparison and other borrowing answers. The deposits bucket fills only from saving-goal answers (pattern 5, when the customer asked how to save up with deposits) and from deposits opened through Raiffy.

| | Loans bucket | Deposits bucket |
| --- | --- | --- |
| Holds | Every borrowing route chosen: personal loan, car loan, mortgage, leasing, overdraft, card | Every saving route chosen: savings account, term deposit, regular savings |
| Each item shows | Product, amount, term, monthly payment, DAE, total cost, every commission, status, next payment date | Target amount, target date, monthly contribution, product, interest rate, projected balance, status |
| Statuses | `planned`, `applied`, `signed`, `active`, `repaid` | `planned`, `opened`, `onTrack`, `behind`, `reached` |
| Bucket totals | Total monthly payments and total cost of credit | Total monthly contributions and projected balance at each target date |
| Action | "Apply in Smart Mobile", pre-filled (existing handoff) | "Open in Smart Mobile", pre-filled with product, amount and term, and "Set up a standing order", pre-filled with amount, day and the customer's own savings account as the destination |
| Progress comes from | Official-flow events for the loan | The linked savings product's balance, if the customer allows it under "What Raiffy can see"; otherwise the customer updates progress by hand |

- The plan header shows the **monthly commitment** (loan payments plus savings contributions) next to the declared income (`docs/shared/customer-experience.md` §1). The affordability gauge counts loan payments only, because savings contributions can be paused; the commitment line shows both.
- **Raiffy never moves money.** Opening a deposit and setting up a standing order are confirmed by the customer inside Smart Mobile, as with any payment (existing hard limit: no payment collection).
- A saving goal is as easy to act on as a loan: one tap opens the deposit or the standing order, pre-filled.

## Keeping the plan current

The plan reacts to changes. Every update is computed by the tools and rebuilt by the composer, never written by the LLM.

| Event | What happens |
| --- | --- |
| A new catalog or pricing version is published (`docs/shared/console.md` → Change lifecycle) | Affected items recalculated; the plan shows "Figures updated" with before and after |
| The index (IRCC, ROBOR or EURIBOR) changes for a variable-rate loan in the plan | Monthly payment recalculated, with the new index value, its source and its date |
| A deposit rate changes, or a term deposit matures | Projected balance recalculated; at maturity, the options are to renew, put it toward the goal or move it to savings |
| The customer changes a declared figure | Affordability and commitment recalculated |
| A deposit goal falls behind or is reached | Status changes; when a goal is reached, the next step for that goal is offered |
| A target date passes | The customer is asked to move the date or close the goal |

- A verification badge expires when the figures it covered change ("Changed after verification"), as already specified.
- **Plan updates** reach the customer as service messages only if they turned on "Keep me posted about this plan" (requested service messages, no marketing consent needed). The limits and channels are in `docs/shared/smart-mobile-integration.md` → Reminders.
- In hardship or crisis mode, plan updates that suggest a product are paused. Factual updates, such as a rate change on an existing loan, still go out.

## After the first signed solution: Raiffeisen options by default

**Rule:** once the customer has signed their **first financial solution at Raiffeisen through a Raiffy plan** (an official-flow `signed` event for any item, loan or deposit), Raiffy stops comparing with competitors by default, in every later answer and plan update, for every goal.

| Rule | Layer |
| --- | --- |
| Answers show Raiffeisen routes only, still ranked by total cost (the answer-scope rule applies unchanged) | Behavior rules |
| The `comparison` block is left out. The `routes` block carries `competitorsCompared: false`, and the answer shows one plain line: "Showing Raiffeisen options · Compare with other banks". The customer always knows the scope | Hard limits · Behavior rules |
| **Competitors are compared only when the customer asks:** they name another bank, ask to compare with other banks or the market, upload a competitor's SECCI or ESIS, tap "Compare with other banks", or turn on "Watch other banks too" for a plan. Then patterns 2 and 11 apply in full, including saying so when a competitor is cheaper and the counter-offer rules | Behavior rules |
| While competitors aren't compared, Raiffy never says or implies that Raiffeisen is the cheapest or best on the market. It may say "the best fit among Raiffeisen options". The evaluator fails market-wide claims when `competitorsCompared` is false | Hard limits |
| Plan updates and alerts are Raiffeisen-only, for example a cheaper Raiffeisen product for an existing goal, or a lower price once the customer meets a condition. They mention another bank only if "Watch other banks too" is on | Behavior rules |
| Shared chats: decided per asker, from the asker's own status | Hard limits |
| Customers who held Raiffeisen products before using Raiffy keep the default comparisons until they sign their first solution through a Raiffy plan | Behavior rules |

```ts
type CompetitorPreference = {
  subjectId: string;                         // the customer
  firstSignedViaRaiffyAt?: string;           // from the official-flow event
  defaultMode: "compare" | "raiffeisenOnly"; // "raiffeisenOnly" once firstSignedViaRaiffyAt is set
  watchOtherBanks: { planId: string; since: string }[]; // per-plan opt-in, counts as asking
};
```

## Data model (Convex)

```ts
type LivingPlan = {
  id: string; ownerId: string;
  status: "draft" | "saved" | "verified" | "inProgress" | "active" | "completed" | "archived";
  goals: { goalId: string; summary: string; price?: { amount: number; currency: "RON" | "EUR"; typedByCustomer: true }; targetDate?: string }[];
  loans: LoanItem[];
  deposits: DepositItem[];
  commitment: { monthlyLoanPayments: number; monthlyContributions: number; declaredIncome?: number };
  priceVersionIds: string[];                 // versions every figure was computed with
  verification: Verification;
  planCode?: { code: string; expiresAt: string }; // branch continuity, docs/shared/customer-experience.md §3
  keepMePosted: boolean;
  updatedAt: string;
};

type LoanItem = {
  id: string; goalId: string; productId: string;
  amount: number; termMonths: number; monthly: number; dae: number; total: number;
  commissions: Commission[];
  status: "planned" | "applied" | "signed" | "active" | "repaid";
  handoffId?: string; nextPaymentDate?: string;
};

type DepositItem = {
  id: string; goalId: string; productId: string;
  targetAmount: number; targetDate: string; monthlyContribution: number; rate: number;
  projectedBalance: number; currentBalance?: number; // currentBalance only with the customer's permission
  status: "planned" | "opened" | "onTrack" | "behind" | "reached";
  handoffId?: string; standingOrderHandoffId?: string;
};

type OfficialFlowEvent = {                   // from Smart Mobile or core banking; mocked in the POC
  handoffId: string;
  kind: "applied" | "signed" | "withdrawn" | "opened" | "repaid" | "matured" | "closed";
  at: string;
};
```

`PlanSummary` (`docs/shared/plan-summary-handoff.md`) gains `loans`, `deposits`, `commitment` and `planCode`, and shows the two buckets as two sections, each with its own totals.

## HTML prototype

- The plan view with two columns (two stacked sections on mobile): Loans and Deposits, each with its items, totals and its one action.
- The BMW personal loan in the loans bucket, and a separate saving goal (from a pattern 5 question) in the deposits bucket.
- A "Figures updated" moment after a mock price change, with before and after.
- A mock `signed` event, after which the next answer shows "Showing Raiffeisen options · Compare with other banks"; tapping it brings the comparison strip back.

## Evals

| Check | Source |
| --- | --- |
| Every chosen route lands in exactly one bucket; the deposits bucket fills only from pattern 5 answers or deposits opened through Raiffy | Two buckets |
| Statuses `applied`, `signed`, `opened` and `repaid` come only from official-flow events | Lifecycle |
| The deposits action pre-fills Smart Mobile and never moves money | Two buckets |
| Plan updates are computed by tools and match the calculator to the cent | Keeping the plan current |
| After a `signed` event, answers leave out the comparison block, show the scope line, and still rank every eligible Raiffeisen borrowing route by total cost in the `solution` scope | After the first signed solution |
| After signing, naming another bank, tapping "Compare with other banks" or uploading a SECCI brings full comparisons back, including saying so when a competitor is cheaper | After the first signed solution |
| No market-wide "cheapest" or "best rate" claim appears while `competitorsCompared` is false | After the first signed solution |
| A customer with older Raiffeisen products but nothing signed through Raiffy still sees comparisons by default | After the first signed solution |
| Product-suggesting plan updates are paused in hardship and crisis modes | Keeping the plan current |

## Check with compliance

- Whether showing Raiffeisen options only after the first signing, with the visible scope line and a one-tap comparison, meets the Consumer Credit Directive's disclosure for advisory services (whether only the lender's own range is considered) and the rules on misleading omissions (Law 363/2007).
- How to describe the deposits bucket's projected balances so they're not read as a guaranteed return.
